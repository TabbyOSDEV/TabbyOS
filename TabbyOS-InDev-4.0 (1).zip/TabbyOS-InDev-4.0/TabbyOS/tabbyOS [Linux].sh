#!/bin/bash

# ============================
# COLORS
# ============================
color1="\e[92m"   # green
color2="\e[91m"   # red
color3="\e[97m"   # white
reset="\e[0m"

currentColor="$color1"

# ============================
# ALIASES
# ============================
declare -A aliases
aliases["print"]="print"

# ============================
# BOOT SEQUENCE
# ============================
clear
echo -e "${currentColor}RetroOS v3.8${reset}"
sleep 0.3
echo -e "${currentColor}Booting kernel...${reset}"
sleep 0.3
echo -e "${currentColor}Loading memory...${reset}"
sleep 0.3
echo -e "${currentColor}Initializing system...${reset}"
sleep 0.3
echo -e "${currentColor}Ready.${reset}"
echo

# ============================
# MAIN LOOP
# ============================
while true; do
    echo -en "${currentColor}RETRO>${reset} "
    read -r cmd

    fullcmd="$cmd"

    # Extract base command
    base="${cmd%% *}"

    # Apply alias if exists
    if [[ -n "${aliases[$base]}" ]]; then
        base="${aliases[$base]}"
    fi

    echo -e "${currentColor}RETRO> $fullcmd${reset}"

    # ============================
    # COMMAND HANDLER
    # ============================

    case "$base" in
        print)
            if [[ "$fullcmd" == *"-"* ]]; then
                msg="${fullcmd#*-}"
                echo -e "$currentColor$msg$reset"
            else
                echo "Usage: print -message"
            fi
            ;;

        sysinf)
            echo "--- SYSTEM INFO ---"
            echo "OS: RetroOS v3.8"
            echo "Kernel: Bash-Simulated"
            echo "Memory: 64KB"
            echo "Display: Monochrome"
            echo "User: guest"
            echo "-------------------"
            ;;

        help)
            echo "--- COMMANDS ---"
            echo "print -message"
            echo "sysinf"
            echo "help"
            echo "adhelp"
            echo "clear"
            echo "clear_prev.(n)"
            echo "txtcolor.(1-3)"
            echo "----------------"
            ;;

        adhelp)
            echo "--- ADVANCED COMMANDS ---"
            echo "edit_langg.print__(alias)"
            echo "edit_langg__(alias)"
            echo "Create shortcuts for commands"
            echo "-----------------------------"
            ;;

        clear)
            clear
            ;;

        *)
            # clear_prev.(n)
            if [[ "$fullcmd" =~ ^clear_prev\.([0-9]+)$ ]]; then
                num="${BASH_REMATCH[1]}"
                for ((i=0; i<num; i++)); do echo; done
                continue
            fi

            # txtcolor.(n)
            if [[ "$fullcmd" =~ ^txtcolor\.([1-3])$ ]]; then
                case "${BASH_REMATCH[1]}" in
                    1) currentColor="$color1" ;;
                    2) currentColor="$color2" ;;
                    3) currentColor="$color3" ;;
                esac
                echo "Color changed"
                continue
            fi

            # edit_langg
            if [[ "$fullcmd" =~ edit_langg(\.([a-zA-Z0-9_]+))?__\(([a-zA-Z0-9_]+)\) ]]; then
                target="${BASH_REMATCH[2]}"
                aliasname="${BASH_REMATCH[3]}"

                [[ -z "$target" ]] && target="print"

                aliases["$aliasname"]="$target"
                echo "Alias created: $aliasname -> $target"
                continue
            fi

            echo "Unknown command"
            ;;
    esac
done
