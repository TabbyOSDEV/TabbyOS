@echo off
title TabbyOS - Retro Terminal
color 0a
setlocal enabledelayedexpansion

:: ============================
::  COLORS
:: ============================
set color1=0a
set color2=0c
set color3=0f
set currentColor=1

:: ============================
::  ALIASES
:: ============================
set alias.print=print

:: ============================
::  BOOT SEQUENCE
:: ============================
cls
echo RetroOS v4.0
ping -n 2 localhost >nul
echo Booting kernel...
ping -n 2 localhost >nul
echo Loading memory...
ping -n 2 localhost >nul
echo Initializing system...
ping -n 2 localhost >nul
echo Ready.
echo.

:: ============================
::  MAIN LOOP
:: ============================
:loop
set /p cmd=RETRO^>

:: Save raw command
set fullcmd=%cmd%

:: Extract base command
for /f "tokens=1 delims= " %%A in ("%cmd%") do set base=%%A

:: Apply alias if exists
for /f "tokens=1,2 delims==" %%A in ('set alias.') do (
    if "!base!"=="%%A" set base=%%B
)

echo RETRO^> %fullcmd%

:: ============================
::  COMMAND HANDLER
:: ============================

if "%base%"=="print" goto cmd_print
if "%base%"=="sysinf" goto cmd_sysinf
if "%base%"=="help" goto cmd_help
if "%base%"=="adhelp" goto cmd_adhelp
if "%base%"=="clear" goto cmd_clear

echo %fullcmd% | findstr /b "clear_prev." >nul && goto cmd_clearprev
echo %fullcmd% | findstr /b "txtcolor." >nul && goto cmd_color
echo %fullcmd% | findstr /b "edit_langg" >nul && goto cmd_editlang

echo Unknown command
goto loop

:: ============================
::  COMMAND: print
:: ============================
:cmd_print
echo %fullcmd% | findstr "-" >nul || (
    echo Usage: print -message
    goto loop
)

set msg=%fullcmd:*-=%
echo %msg%
goto loop

:: ============================
::  COMMAND: sysinf
:: ============================
:cmd_sysinf
echo --- SYSTEM INFO ---
echo OS: RetroOS v4.0

:: Windows version
for /f "tokens=2 delims=[]" %%A in ('ver') do set winver=%%A
echo Host Kernel: Windows %%winver%%

:: CPU
for /f "skip=1 tokens=*" %%A in ('wmic cpu get name') do (
    if not "%%A"=="" (
        set cpu=%%A
        goto cpu_done
    )
)
:cpu_done
echo CPU: %cpu%

:: RAM
for /f "tokens=2 delims==" %%A in ('wmic computersystem get TotalPhysicalMemory /value') do set ram=%%A
set /a ramMB=%ram:~0,-6%
echo RAM: %ramMB% MB

:: GPU
for /f "skip=1 tokens=*" %%A in ('wmic path win32_VideoController get name') do (
    if not "%%A"=="" (
        set gpu=%%A
        goto gpu_done
    )
)
:gpu_done
echo GPU: %gpu%

:: Username
echo User: %USERNAME%

echo -------------------
goto loop

:: ============================
::  COMMAND: help
:: ============================
:cmd_help
echo --- COMMANDS ---
echo print -message
echo sysinf
echo help
echo adhelp
echo clear
echo clear_prev.(n)
echo txtcolor.(1-3)
echo ----------------
goto loop

:: ============================
::  COMMAND: adhelp
:: ============================
:cmd_adhelp
echo --- ADVANCED COMMANDS ---
echo edit_langg.print__(alias)
echo edit_langg__(alias)
echo Create shortcuts for commands
echo -----------------------------
goto loop

:: ============================
::  COMMAND: clear
:: ============================
:cmd_clear
cls
goto loop

:: ============================
::  COMMAND: clear_prev.(n)
:: ============================
:cmd_clearprev
for /f "tokens=2 delims=." %%A in ("%fullcmd%") do set num=%%A

if "%num%"=="" (
    echo Invalid number
    goto loop
)

for /l %%i in (1,1,%num%) do echo.
goto loop

:: ============================
::  COMMAND: txtcolor.(n)
:: ============================
:cmd_color
for /f "tokens=2 delims=." %%A in ("%fullcmd%") do set num=%%A

if "%num%"=="1" set currentColor=1&color %color1%&echo Color changed&goto loop
if "%num%"=="2" set currentColor=2&color %color2%&echo Color changed&goto loop
if "%num%"=="3" set currentColor=3&color %color3%&echo Color changed&goto loop

echo Invalid color
goto loop

:: ============================
::  COMMAND: edit_langg
:: ============================
:cmd_editlang
:: Syntax: edit_langg.print__(alias)
:: OR:     edit_langg__(alias)

set line=%fullcmd%

:: Extract target + alias
for /f "tokens=1,2 delims=(" %%A in ("%line%") do (
    set left=%%A
    set alias=%%B
)

set alias=%alias:)=%

:: Determine target
echo %left% | findstr "\." >nul && (
    for /f "tokens=2 delims=." %%A in ("%left%") do set target=%%A
) || (
    set target=print
)

set alias.%alias%=%target%
echo Alias created: %alias% -> %target%
goto loop
